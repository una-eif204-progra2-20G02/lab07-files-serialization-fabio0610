# External Libraries
This folder is to use for external libraries, for example:

**Testing Framework**
- Google Test
- Catch